//
//  Pessoa.swift
//  RoletaRussa
//
//  Created by Alan Silva on 29/07/21.
//

import Foundation

struct Pessoa {
    var nome: String
    var idImagem: String
    var pagamento: Bool
}
